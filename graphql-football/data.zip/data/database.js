const players = {
  1: {
    id: '1',
    dateofbirth: '01.01.1980',
    firstname: 'Alan',
    lastname: 'Shearer',
    teams: ['1'],
  },
  2: {
    id: '2',
    dateofbirth: '01.01.1980',
    firstname: 'Ian',
    lastname: 'Rush',
    teams: ['2', '3'],
  },
};

const teams = {
  1: {
    id: '1',
    name: 'Newcastle',
  },
  2: {
    id: '2',
    name: 'Liverpool FC',
  },
  3: {
    id: '3',
    name: 'Juventus',
  },
};


export const get = (args) => Object.keys(players)
  .map(k => players[k])
  .filter(k => !Object.keys(args).length || k.firstname === args.firstname);
export const getById = (id) => players[id];
export const getTeamById = (id) => teams[id];
export const getTeams = () => Object.keys(teams).map(t => teams[t]);
