import {
  GraphQLSchema,
  GraphQLObjectType,
  GraphQLString,
  GraphQLList,
} from 'graphql';


import { get, getTeams } from './database';

const teamType = new GraphQLObjectType({
  name: 'Team',
  fields: () => ({
    name: { type: GraphQLString },
  }),
});

const userType = new GraphQLObjectType({
  name: 'Player',
  fields: () => ({
    id: { type: GraphQLString },
    firstname: { type: GraphQLString },
    lastname: { type: GraphQLString },
    dateofbirth: { type: GraphQLString },
    teams: {
      type: new GraphQLList(teamType),
      resolve: (player) => getTeams().filter(p => player.teams.indexOf(p.id) > -1) },
  }),
});

export const schema = new GraphQLSchema({
  query: new GraphQLObjectType({
    name: 'Query',
    fields: () => ({
      players: {
        type: new GraphQLList(userType),
        description: 'List of players',
        args: {
          firstname: { type: GraphQLString },
        },
        resolve: (_, args) => get(args),
      },
    }),
  }),
});
